document.addEventListener('DOMContentLoaded', () => {
  const buttons = document.querySelectorAll('.filters button');
  const grid = document.querySelector('.grid');

  const iso = new Isotope(grid, {
    itemSelector: 'a',
    layoutMode: 'fitRows'
  });

  buttons.forEach(button => {
    button.addEventListener('click', () => {
      const filterValue = button.getAttribute('data-filter');
      iso.arrange({ filter: filterValue });

      buttons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
    });
  });
});
